import express from 'express'
import { register, login, getMe } from '../controllers/auth.controller.js'
import { protect } from '../middlewares/auth.middleware.js'
import validate from '../middlewares/validate.middleware.js'
import { registerValidator, loginValidator } from '../validators/auth.validator.js'

const router = express.Router()

router.post('/register', registerValidator, validate, register)
router.post('/login', loginValidator, validate, login)
router.get('/me', protect, getMe);

export default router;